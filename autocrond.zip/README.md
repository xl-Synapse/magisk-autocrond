# 自启crond服务

**默认路径为 /data/local/tmp/crontabJob**
编辑命令：
    crontab -c /data/local/tmp/crontabJob -e

